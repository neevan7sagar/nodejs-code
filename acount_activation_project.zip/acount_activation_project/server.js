const express = require('express')
const app = express();
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const userRoute = require('./src/routes/user.routes')
app.use(bodyParser.json())
const auth = require('./src/middlewares/user.middleware')
const  db = require('./config/database')
mongoose.connect(db.url,{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log("Database connected successfully")
}).catch(err=>{
    console.log(err)
})
//app.use(auth.chektoken)
app.use('/', userRoute)

const port = process.env.port || 3000
app.listen(port,()=>{
    console.log(`server is running on port ${port}`)
})