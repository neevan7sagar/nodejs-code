const express = require('express')
const router = express.Router();
const bodyParser = require('body-parser')
router.use(bodyParser.json())
const usercontrollers = require('../controllers/user.controllers')
const usermiddlewares = require('../middlewares/user.middleware')
//Routers
router.post('/signup',usercontrollers.usersignup)
router.get('/useracountactivation/:token',usercontrollers.useracount_activation)
router.post('/login',usercontrollers.userlogin)
router.post('/refreshtoken',usercontrollers.refreshToken)
router.get('/users',usermiddlewares.chektoken,usercontrollers.getAllUser)


module.exports = router
