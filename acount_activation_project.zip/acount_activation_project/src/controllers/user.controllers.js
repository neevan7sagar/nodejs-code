const usermodels = require('../models/user.models')
require('dotenv').config()
const nodemailer = require('nodemailer')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt');
const et = require('bcrypt');

exports.usersignup = async (req, res)=>{
  try { 
    const salt = await bcrypt.genSalt(10);
    req.body.password = await bcrypt.hash(req.body.password, salt);
    const user = await usermodels.findOne({email: req.body.email});
    if (!user) {
      usermodels.create(req.body).then((user)=>{
        const token = jwt.sign({email: user.email}, process.env.ACCESS_TOKEN_SECRET, {'expiresIn': '1d'});
        const link = 'http://localhost:3000/useracountactivation/'+token;
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          secure: false,
          port: 587,
          auth: {
            user: process.env.email,
            pass: process.env.password,
          },
          tls: {rejectUnauthorized: false},
        });
        const mailOption = {
          from: process.env.email,
          to: user.email,
          subject: 'Account Activation',
          text: link,
        };
        transporter.sendMail(mailOption, (error, info)=>{
          if (error) {
            console.log(error);
          } else {
            console.log(info.response);
            res.send('One confirmation has been send to your email id so need check your mail and click confirm to your acacount activation');
          }
        });
      });
    } else {
      res.send('user is already exist');
    }
  } catch (err) {
    console.log('Error occured', err);
  }
};

exports.useracount_activation = async (req, res)=>{
  try {
    const token = req.params.token;
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, async (err, payload)=>{
      if (err) return res.status(401).send({code: 401, message: 'failure', error: 'token is expired or may be incorrect'});
      const user = await usermodels.findOne({email: payload.email});
      user.isActive= true;
      user.save().then((success)=>{
        res.status(200).send({code: 200, message: 'success', result: 'your account has been activated succesfully'});
      });
    }).catch((err)=>{
      res.json(err);
    });
  } catch (error) {
    console.log('Error occured ', error);
  }
};

exports.userlogin = async (req, res)=>{
  try {
    const user = await usermodels.findOne({email: req.body.email});
    console.log(user);
    if (user) {
      if (user.isActive) {
        const validatePassword = await bcrypt.compare(req.body.password, user.password);
        if (validatePassword) {
          const token = jwt.sign({email: user.email}, process.env.ACCESS_TOKEN_SECRET, {'expiresIn': '1h'});
          const refreshtoken = jwt.sign({email: user.email}, process.env.REFRESH_TOKEN_SECRET, {'expiresIn': '2h'});
          res.send({message: 'Token has been generated successfully', token: token, refreshtoken: refreshtoken});
        } else {
          res.send('Password is incorrect');
        }
      } else {
        res.send('your acount  is not activated yet');
      }
    } else {
      res.send('user is not found ');
    }
  } catch (error) {
    console.log('error occured', error);
  }
};

exports.refreshToken = async (req, res)=>{
  const refreshToken = req.body.refreshToken;
  try {
    if (refreshToken == null) return res.status(401).send('Token not found');
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user)=>{
      if (err) return res.status(401).send('Token is incorrect or may be expired');
      const accessToken = generateAccessToken({email: req.body.email});
      const refreshtoken = jwt.sign({email: user.email}, process.env.REFRESH_TOKEN_SECRET, {'expiresIn': '30m'});
      res.send({accessToken: accessToken, refreshToken: refreshtoken});
    });
  } catch (err) {
    console.log('error occured', error);
  }
};

exports.getAllUser = async (req, res)=>{
  try {
    usermodels.find((err, data)=>{
      if (err) {
        console.log(err);
      } else {
        res.send(data);
      }
    });
  } catch (err) {
    logger.error(err);
    res.send('Error occured', err);
  }
};

function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, {'expiresIn': '15m'});
}

