const bodyParser = require('body-parser')
const usermodels = require('../models/user.models')
require('dotenv').config()
const nodemailer = require('nodemailer')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')
const Messages = require('../../config/message')
const logger = require('../../config/logger')
const express = require('express')
const app = express()

const message = require('../../config/message')
app.use(bodyParser.urlencoded({extended:true}))
// Insert Signup  Code Here
exports.usersignup = async (req, res) => {
  try {
    // console.log(req.body)
    const salt = await bcrypt.genSalt(10); 
    req.body.password = await bcrypt.hash(req.body.password, salt);
    const user = await usermodels.findOne({ email: req.body.email });
    if (!user) {
      usermodels.create(req.body).then((user) => {
        const token = jwt.sign({ email: user.email }, process.env.ACCESS_TOKEN_SECRET, { 'expiresIn': '1d' });
        const link = 'http://localhost:3000/useracountactivation/' + token;
        console.log(link)
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          secure: false,
          port: 587,
          auth: {
            user: process.env.email,
            pass: process.env.password,
          },
          tls: { rejectUnauthorized: false },
        });
        const mailOption = {
          from: process.env.email,
          to: user.email,
          subject: 'Account Activation',
          text: link,
        };
        transporter.sendMail(mailOption, (error, info) => {
          if (error) {
            console.log(error);
          } else {
            logger.info("Confirmation email has been sent to this email address" + user.email)
            console.log(info.response)
            res.send(Messages.ACCOUNT_ACTIVATION);
          }
        });
      });
    } else {
      res.send('user is already exist');
    }
  } catch (err) {
    console.log('Error occured', err);
  }
};
// insert useracount_activation  Code Here
exports.useracount_activation = async (req, res) => {
  try {
    const token = req.params.token;
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, async (err, payload) => {
      if (err) return res.status(401).send({ code: 401, message: 'failure', error: Messages.TOKEN_EXPIRED });
      const user = await usermodels.findOne({ email: payload.email });
      user.isActive = true;
      user.save().then((success) => {
        res.status(200).send({ code: 200, message: 'success', result: Messages.ACCOUNT_SUCCESSFUL });
      });
    }).catch((err) => {
      res.json(err);
    });
  } catch (error) {
    console.log('Error occured ', error);
  }
};
// insert  Login Code Here
exports.userlogin = async (req, res) => {
  try {
    const user = await usermodels.findOne({ email: req.body.email });
    console.log(user);
    if (user) {
      if (user.isActive) {
        const validatePassword = await bcrypt.compare(req.body.password, user.password);
        if (validatePassword) {
          const token = jwt.sign({ email: user.email }, process.env.ACCESS_TOKEN_SECRET, { 'expiresIn': '1h' });
          const refreshtoken = jwt.sign({ email: user.email }, process.env.REFRESH_TOKEN_SECRET, { 'expiresIn': '2h' });
          res.send({ message: Messages.TOKEN_SUCCESS, token: token, refreshtoken: refreshtoken });
        // res.render('welcome', {email:user.email} )
        } else {
          res.send('Password is incorrect');
        }
      } else {
        res.send('your acount  is not activated yet');
      }
    } else {
      res.send('user is not found ');
    }
  } catch (error) {
    console.log('error occured', error);
  }
};
// insert refeshtoken  code Here
exports.refreshToken = async (req, res) => {
  const refreshToken = req.body.refreshToken;
  try {
    if (refreshToken == null) return res.status(401).send('Token not found');
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
      if (err) return res.status(401).send(Messages.TOKEN_EXPIRED);
      const accessToken = generateAccessToken({ email: req.body.email });
      const refreshtoken = jwt.sign({ email: user.email }, process.env.REFRESH_TOKEN_SECRET, { 'expiresIn': '30m' });
      res.send({ accessToken: accessToken, refreshToken: refreshtoken });
    });
  } catch (err) {
    console.log('error occured', error);
  }
};

exports.getAllUser = async (req, res) => {
  try {
    usermodels.find((err, data) => {
      if (err) {
        console.log(err);
      } else {
        res.send(data);
      }
    });
  } catch (err) {
    logger.error(err);
    res.send('Error occured', err);
  }
};

function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { 'expiresIn': '15m' });
}

exports.forgetpassword = async(req,res)=>{
  try{
    const {email} = req.body
    const user = await usermodels.findOne({email:req.body.email})
    if(!user){
     return res.status(400).send("user is not exist")
    }
   //create email and send token  
    else{
      const token = jwt.sign({ email: user.email }, process.env.RESET_PASSWORD_KEY, { 'expiresIn': '1d' });
      const link = 'http://localhost:3000/resetpassword/' + token;
      console.log(link)
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        secure: false,
        port: 587,
        auth: {
          user: process.env.email,
          pass: process.env.password,
        },
        tls: { rejectUnauthorized: false },
      });
      const mailOption = {
        from: process.env.email,
        to: user.email,
        subject: 'forget password request',
        text: link,
      };
      transporter.sendMail(mailOption, (error, info) => {
        if (error) {
          console.log(error);
        } else {
        //  console.log(info.response)
          res.send("Email has been sent please check your email ");
        }
      });
    }
  }catch(err){
  res.send("Error occured",err)
  }
}



exports.resetpassword = async(req,res)=>{
  try{
  const token = req.params.token;
  console.log(token)
    jwt.verify(token, process.env.RESET_PASSWORD_KEY, async (err, payload) => {
      if (err) return res.status(401).send({ code: 401, message: 'failure', error: Messages.TOKEN_EXPIRED });
      const user = await usermodels.findOne({ email: payload.email });
        
      const salt = await bcrypt.genSalt(10); 
      req.body.newPassword = await bcrypt.hash(req.body.newPassword, salt);
      user.password = req.body.newPassword
      
      user.save().then((success) => {
        res.status(200).send({ code: 200, message: 'success', result: Messages.RESET_PASSWORD });
      });
    }).catch((err) => {
      res.json(err);
    })
  } catch (err) {
    console.log('Error occured ', err);
  }
}