
const jwt = require('jsonwebtoken');
const User = require('../models/user.models')
const Messages = require('../../config/message')
const { validationResult} = require('express-validator');



//insert chektoken code here
exports.chektoken = (req,res,next)=>{
    try{
     const header = req.headers.authorization;
     const token = header && header.split(' ')[1]
     console.log(token)
     if(token == null) return res.send("Token is not found")
    
     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET,(err, verifiedJwt)=>{
         if(err) return res.send(Messages.TOKEN_EXPIRED)
         next();
     })
    }catch(err){
        res.send("error occured",err)
    }
}
 
// insert validate email and password code here
exports.validate = (req,res,next)=>{
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
          return res.status(400).send({error:errors.array()})
    }
next()
}
