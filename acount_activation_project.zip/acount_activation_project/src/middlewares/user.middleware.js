
const jwt = require('jsonwebtoken');


exports.chektoken = (req,res,next)=>{
    try{
     const header = req.headers.authorization;
     const token = header && header.split(' ')[1]
     console.log(token)
     if(token == null) return res.send("Token is not found")
     // eslint-disable-next-line no-undef
     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET,(err, verifiedJwt)=>{
         if(err) return res.send("token is expired or may be incorrect")
         next();
     })
    }catch(err){
        res.send("error occured",err)
    }
 }

