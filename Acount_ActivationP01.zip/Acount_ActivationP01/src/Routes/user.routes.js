const express = require('express')
const router = express.Router();
const bodyParser = require('body-parser')
router.use(bodyParser.json())
//require logger.js
const usermiddleware = require('../Middleware/user.middleware')
const usercontroller = require('../Controllers/user.controllers');


//Routers
router.post('/signup', usercontroller.usersignup);
router.post('/signin', usercontroller.usersignin);
router.get('/accountctivation:token', usercontroller.accountActivation);
router.post('/refreshtoken',usercontroller.refreshtoken);
router.get('/checktoken',usercontroller.checktoken)

module.exports = router