const jwt = require('jsonwebtoken');
const message = require('../../config/message');
const router = require('../Routes/User.Routes');

const chektoken = (req,res,next)=>{
    try{
     const header = req.headers.authorization;
     const token = header && header.split(' ')[1]
     console.log(token)
     if(token == null) return res.send("token is not found")
     jwt.verify(token,process.env.ACCESS_TOKEN_SECRET,(err,verifiedJwt)=>{
         if(err) return res.send(message.USER_TOKEN_EXPIRED)
         next();
     })
    }catch(err){
        res.send("error occured",err)
    }
 }
 router.use(chektoken);