const usermodels = require('../Models/user.models')
const bcrypt = require('bcrypt');
require('dotenv').config()
const jwt = require('jsonwebtoken');
const message = require('../../config/message');

exports.usersignup = async(req,res)=>{
    try{
        const salt = await bcrypt.genSalt(10)
        req.body.password = await bcrypt.hash(req.body.password,salt)
        const user =  await EmpModel.findOne({email:req.body.email})
    if(!user){
        EmpModel.create(req.body).then(user=>{
        logger.info("New user created with email address" + user.email)
        const token = jwt.sign({email:user.email},process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"1d"})
        const link = "http://localhost:3000/accountactivation"+token
        const transporter = nodemailer.createTransport({
            service:"gmail",
            secure:false,
            port:587,
         auth:{
            user:process.env.email,
            pass:process.env.password
         },
         tls: {rejectUnauthorized: false}
        })
        const mailData = {
            from:process.env.email,
            to:user.email,
            subject:"Account Activation",
            text:link
        };
        transporter.sendMail(mailData,(error,info)=>{
        if(error){
            console.log(error)
        }else{
            logger.info("Confirmation email has been sent to this email address" + user.email)
            console.log(info.response)
            res.send(message.USER_CREATED)
        }
    })
})
    }
else{
    res.send("user is already exist")
}
    }catch(err){
res.send("error oocured",err)
    }
}


exports.usersignin = async(req,res)=>{
    try{
        const user =  await EmpModel.findOne({email:req.body.email})
        console.log(user)
        if(user){
            if(user.isActive){
                const validatePassword = await bcrypt.compare(req.body.password,user.password)
                if(validatePassword){
                       const token = jwt.sign({email:user.email},process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"30m"})
                      const refreshtoken = jwt.sign({email:user.email},process.env.REFRESH_TOKEN_SECRET,{"expiresIn":"45m"})
                    res.send({message:USER_TOKEN,token:token,refreshToken:refreshtoken})
                }else{
                    res.send("Password is incorrect")
                }
            }
            else{
                res.send("Your account is not activated yet")
            }
        }
        else{
            res.send("User is not found")
        }
    }catch(err){
        res.send("Error occured",err)

    }  
}

exports.accountActivation = async(req,res)=>{
    try{
      const token = req.params.token
      jwt.verify(token,process.env.ACCESS_TOKEN_SECRET,async(err,payload)=>{
      if(err)return res.status(401).send({code:401,message:"failure",error:message.USER_TOKEN_EXPIRED})
      const user = await EmpModel.findOne({email:payload.email})
      user.isActive = true
      user.save().then((success)=>{
          res.status(200).send({code:200,message:"success",result:message.USER_ACTIVATED})
      }).catch((err)=>{
          res.json(err)})
      })
    }catch(err){
        res.send("Error oocured",err)
  
    }
  }
exports.refreshtoken = (req,res)=>{
    // const refreshToken = req.body.refreshToken;
    try{
     const header = req.headers.authorization;
     const token = header && header.split(' ')[1]
     console.log(token)
     if(token == null) return res.status(401).send("token not found")
     jwt.verify(token,process.env.REFRESH_TOKEN_SECRET,(err,user)=>{
         if(err) return res.status(401).send(message.USER_TOKEN_EXPIRED)
         const accessToken = generateAccessToken({email:req.body.email})
         const refreshtoken = jwt.sign({email:user.email},process.env.REFRESH_TOKEN_SECRET,{"expiresIn":"30m"})
         res.send({token:accessToken,refreshToken:refreshtoken})
     })
  } catch(err){
        res.send("Error occured", err)
    }
    
}


  
exports.checktoken    = async(req,data)=>{
        try{
            EmpModel.find((err,data)=>{
            if(err){
                console.log(err)
            }
            else{
                res.send(data)
            }
        })
    }catch(err){
        logger.error(err)
        res.send("Error occured",err)

    }
}
function generateAccessToken(user){
    return jwt.sign(user,process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"15m"})
}