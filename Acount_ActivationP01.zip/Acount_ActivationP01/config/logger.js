const {createLogger,transports,format} = require('winston')

const customFormat = format.combine(format.timestamp(),format.printf((info)=>{
    return ` ${new Date(Date.now()).toUTCString()} | ${info.level.toUpperCase().padEnd(7)} | ${info.message}`
}))

const logger = createLogger({
    format:customFormat,
    transports:[
        new transports.Console(),
        new transports.File({filename: "account_activation.log"})
    ]
});
module.exports = logger;