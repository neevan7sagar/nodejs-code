module.exports = {
    DATABASE:"Database Created Successfully",
    USER_CREATED:"Confirmation email has been sent to your email addrsss so you need to click confirm to your account activation ",
    USER_ACTIVATED:"your account has been activated successfully",
    USER_TOKEN:"Token has been Generate successfully",
    USER_TOKEN_EXPIRED:"token is expired or may be incorrect",
    PORT:"server is ready on ${port}",
}