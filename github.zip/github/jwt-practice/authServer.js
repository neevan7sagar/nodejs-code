require('dotenv').config()
//this will allow us to pull params from .env file
const express = require('express')
const jwt = require('jsonwebtoken')
// const TOKEN_SERVER_PORT=4000
const app = express()

app.use(express.json())
//this middleware allow us to pull req.body<params>

const port = process.env.TOKEN_SERVER_PORT

//get the port number from .env file
//npm i bcrypt jsonwebtoken
const bcrypt = require('bcrypt')// bcrypt will be used for hash password 
const users = []


//Register a  user
app.post('/createUser',async(req,res)=>{
    const user = req.body.name
    const hashedpassword = await bcrypt.hash(req.body.password,10)
    users.push({user:user,password:hashedpassword})
    res.status(201).send(users)
    console.log(users)   
}) 
//authenticate login and return jwt token
app.post('/login',async(req,res)=>{
    console.log(users)
    const user = users.find( (c)=> c.user == req.body.name)
    if(user == null)res.status(404).send("Users does not exist!")
    if(await bcrypt.compare(req.body.password,user.password)){
       // const accessToken = generateAccessToken({user:req.body.name})
       // const refreshToken = generateRefreshToken({user:req.body.name})
        res.json({accessToken:accessToken,refreshToken:refreshToken})
    }
    else{
        res.status(401).send("Password Incorrect")
    }

})
//access tokens
function generateAccessToken(user){
    return jwt.sign(user,process.env.ACCESS_TOKEN_SECRET,{expiresIn:"15m"})
}


//refreshTokens
let refreshTokens = []
function generateRefreshToken(user){
    const refreshToken = jwt.sign(user,process.env.REFRESH_TOKEN_SECRET,{expiresIn:"20m"})
    refreshTokens.push(refreshToken)
    return refreshToken;
}
//refresh token api
app.post('/refreshtoken',(req,res)=>{
    if(!refreshTokens.includes(req.body.token))
    res.status(400).send("Refresh Invalid token")

    refreshTokens = refreshTokens.filter( (c)=>c !=req.body.token)

    //remove the old refresh token form the refresh token list
    const accessToken = generateAccessToken({user:req.body.name})
    const refreshToken = generateRefreshToken({user:req.body.name})

    //generate new accressToken and refreshtoken
    express.json({accessToken:accessToken,refreshToken:refreshToken})
})

app.delete('/logout',(req,res)=>{
    refreshTokens = refreshTokens.filter( (c)=> c!=req.body.name)
    //remove the old refresh token from the refresh token list 
    res.status(204).send("Logged out")

})


app.listen(port,()=>{
    console.log(`Authtorization server running on port ${port}`)
    
})
