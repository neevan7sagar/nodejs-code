const bodyParser = require('body-parser');
const express = require('express')
const app = express();
const mongoose = require('mongoose')
const EmpModel = require('./EmpSchema')
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer')
const logger = require('./logger')

require('dotenv').config()
const bcrypt = require('bcrypt');

var port = process.env.PORT || 5000;
app.use(bodyParser.json())

const query = "mongodb+srv://admin:admin@cluster0.b9pn7.mongodb.net/mydatabase?retryWrites=true&w=majority"
mongoose.connect(query,{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log("Database Created Successfully")
}).catch(err=>{
    console.log(err)
})


app.post('/signup',async(req,res)=>{
    try{
        const salt = await bcrypt.genSalt(10)
    req.body.password = await bcrypt.hash(req.body.password,salt)
      const user =  await EmpModel.findOne({email:req.body.email})
    if(!user){
         EmpModel.create(req.body).then(user=>{
            //  logger.info("New user created with email address" + user.email)
        const token = jwt.sign({email:user.email},process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"1d"})
        const link = "http://localhost:3000/account/activation/"+token
        const transporter = nodemailer.createTransport({
            service:"gmail",
            secure:false,
            port:587,
         auth:{
            user:process.env.email,
            pass:process.env.password
         },
         tls: {rejectUnauthorized: false}
        })
        const mailData = {
            from:process.env.email,
            to:user.email,
            subject:"Account Activation",
            text:link
        };
        transporter.sendMail(mailData,(error,info)=>{
        if(error){
            console.log(error)
        }else{
            logger.info("Confirmation email has been sent to this email address" + user.email)
            console.log(info.response)
            res.send("Confirmation email has been sent to your email addrsss so you need to click confirm to your account activation ")
        }
    })
})
    }
else{
    res.send("user is already exist")
}
    }catch(err){
res.send("error oocured",err)
    }
})
app.get('/account/activation/:token',async(req,res)=>{
  try{
    const token = req.params.token
    jwt.verify(token,process.env.ACCESS_TOKEN_SECRET,async(err,payload)=>{
    if(err)return res.status(401).send({code:401,message:"failure",error:"Token is expired or may be incorrect"})
    const user = await EmpModel.findOne({email:payload.email})
    user.isActive = true
    user.save().then((success)=>{
        res.status(200).send({code:200,message:"success",result:"your account has been activated succesfully"})
    }).catch((err)=>{
        res.json(err)})
    })
  }catch(err){
      res.send("Error oocured",err)

  }
})

app.post('/signin',async(req,res)=>{
    try{
        const user =  await EmpModel.findOne({email:req.body.email})
        console.log(user)
        if(user){
            if(user.isActive){
                const validatePassword = await bcrypt.compare(req.body.password,user.password)
                if(validatePassword){
                       const token = jwt.sign({email:user.email},process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"30m"})
                      const refreshtoken = jwt.sign({email:user.email},process.env.REFRESH_TOKEN_SECRET,{"expiresIn":"45m"})
                    res.send({message:"Token has been Generate successfully",token:token,refreshToken:refreshtoken})
                }else{
                    res.send("Password is incorrect")
                }
            }
            else{
                res.send("Your account is not activated yet")
            }
        }
        else{
            res.send("User is not found")
        }
    }catch(err){
        res.send("Error occured",err)

    }
   
})
app.post('/refeshtoken',(req,res)=>{
   // const refreshToken = req.body.refreshToken;
   try{
    const header = req.headers.authorization;
    const token = header && header.split(' ')[1]
    console.log(token)
    if(token == null) return res.status(401).send("token not found")
    jwt.verify(token,process.env.REFRESH_TOKEN_SECRET,(err,user)=>{
        if(err) return res.status(401).send("token is incorrect or may be expired")
        const accessToken = generateAccessToken({email:req.body.email})
        const refreshtoken = jwt.sign({email:user.email},process.env.REFRESH_TOKEN_SECRET,{"expiresIn":"30m"})
        res.send({token:accessToken,refreshToken:refreshtoken})
    })
 } catch(err){
       res.send("Error occured", err)
   }
   
})
function generateAccessToken(user){
    return jwt.sign(user,process.env.ACCESS_TOKEN_SECRET,{"expiresIn":"15m"})
}
   
    const chektoken = (req,res,next)=>{
       try{
        const header = req.headers.authorization;
        const token = header && header.split(' ')[1]
        console.log(token)
        if(token == null) return res.send("token is not found")
        jwt.verify(token,process.env.ACCESS_TOKEN_SECRET,(err,verifiedJwt)=>{
            if(err) return res.send("token is expired or may be incorrect")
            next();
        })
       }catch(err){
           res.send("error occured",err)
       }
    }
    app.use(chektoken);
    app.get('/',(req,data)=>{
        try{
            EmpModel.find((err,data)=>{
                if(err){
                    console.log(err)
                }
                else{
                    res.send(data)
                }
            })
        }catch(err){
            logger.error(err)
            res.send("Error occured",err)

        }
    })


app.listen(port,()=>{
    // console.log(`server is ready on ${port}`)
    logger.info(`server is ready on ${port}`)
})