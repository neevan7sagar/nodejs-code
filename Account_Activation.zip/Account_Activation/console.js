// synchronous js
// console.log("first log")
// console.log("second log")
// console.log("third log")



//Asynchronous js
// console.log("first log")
// setTimeout(() => {
//     console.log("second log")
    
// }, 2000);
// console.log("third log")