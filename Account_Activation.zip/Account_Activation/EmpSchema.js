const mongosose = require('mongoose')
const userSchema = mongosose.Schema({
username:{
    type:String
    // required:true
},
email:{
    type:String
    // required:true
},
password:{
    type:String
    // required:true

},
isActive:{
    type:Boolean,
    default:false
}
})
module.exports = mongosose.model('employee',userSchema)
